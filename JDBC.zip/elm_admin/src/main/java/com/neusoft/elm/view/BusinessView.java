package com.neusoft.elm.view;

import com.neusoft.elm.po.Business;

public interface BusinessView {
    public void listBusinessAll();
    public void listBusiness();
    public void saveBussiness();
    public void removeBussiness();

    public Business login();
    public void showBussiness(Integer businessId);
    public void editBusiness(Integer businessId);
    public void updateBusinessByPassword(Integer businessId);
}
