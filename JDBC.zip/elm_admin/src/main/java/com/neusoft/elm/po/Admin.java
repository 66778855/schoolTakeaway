package com.neusoft.elm.po;

import lombok.Data;

@Data
public class Admin {
    private Integer adminId;
    private String adminName;
    private String password;

}
