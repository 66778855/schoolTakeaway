package com.neusoft.elm.dao.impl;

import com.neusoft.elm.dao.AdminDao;

import static org.junit.Assert.*;

public class AdminDaoImplTest {

    @org.junit.Test
    public void getAdminByNameByPass() {
        String adminName="123";
        String password="123";
        AdminDao adminDao = new AdminDaoImpl();
        adminDao.getAdminByNameByPass(adminName,password);
    }
}