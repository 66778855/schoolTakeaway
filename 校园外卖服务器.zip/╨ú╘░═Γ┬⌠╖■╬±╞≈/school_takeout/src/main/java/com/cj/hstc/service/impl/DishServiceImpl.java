package com.cj.hstc.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cj.hstc.dto.DishDto;
import com.cj.hstc.entity.Dish;
import com.cj.hstc.entity.DishFlavor;
import com.cj.hstc.mapper.DishMapper;
import com.cj.hstc.service.DishFlavorService;
import com.cj.hstc.service.DishService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class DishServiceImpl extends ServiceImpl<DishMapper, Dish> implements DishService {

    @Autowired
    private DishFlavorService dishFlavorService;

    /**
     * 新增菜品
     *
     * @param dishDto
     * @Transactional//开事务
     */
    @Override
    @Transactional//开事务
    public void saveWithFlavor(DishDto dishDto) {
        this.save(dishDto);

        Long dishID = dishDto.getId();//菜品id
        List<DishFlavor> flavors = dishDto.getFlavors();
        //将菜品id加到口味上去
        for (DishFlavor flavor : flavors) {
            flavor.setDishId(dishID);
        }
        dishFlavorService.saveBatch(flavors);
    }
     @Override
    public DishDto getByIdWithFlavor(Long id) {
        Dish dish = this.getById(id);
        DishDto dishDto = new DishDto();
        BeanUtils.copyProperties(dish, dishDto);

        //查询当前菜品对应的口味信息，从dish_flavor表查询
        LambdaQueryWrapper<DishFlavor> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DishFlavor::getDishId, dish.getId());
        List<DishFlavor> flavors = dishFlavorService.list(queryWrapper);
        dishDto.setFlavors(flavors);
        return dishDto;
    }

    /**
     * 查询一个分类中的所有彩品及其口味 并封装为List<DishDto> 进行返回
     * 应用场景：客户端详情页面展示
     * @param categoryId
     * @return
     */

    @Override
    public List<DishDto> getByIdWithFlavorList(Long categoryId) {

        List <DishDto> dishDtoList = new ArrayList<>();
        //构造条件构造器
        LambdaQueryWrapper<Dish> queryWrapper = new LambdaQueryWrapper<>();

        queryWrapper.eq(Dish::getCategoryId, categoryId);
        //只查询状态为1 的启售商品
        queryWrapper.eq(Dish::getStatus, 1);
        //添加排序条件
        queryWrapper.orderByAsc(Dish::getSort).orderByDesc(Dish::getUpdateTime);
        //执行查询
        List<Dish> dishList = this.list(queryWrapper);
        for (Dish dish : dishList) {
            DishDto dishDto = new DishDto();
            BeanUtils.copyProperties(dish, dishDto);
            LambdaQueryWrapper<DishFlavor> dishQueryWrapper = new LambdaQueryWrapper<>();
            dishQueryWrapper.eq(DishFlavor::getDishId,dish.getId());
            List<DishFlavor> dishFlavorList = dishFlavorService.list(dishQueryWrapper);
            dishDto.setFlavors(dishFlavorList);
            dishDtoList.add(dishDto);
        }
        return dishDtoList;
    }

    @Override
    @Transactional//开事务
    public void updateWithFlavor(DishDto dishDto) {
        this.updateById(dishDto);

        Long dishID = dishDto.getId();//菜品id
        List<DishFlavor> flavors = dishDto.getFlavors();

        //删除当前菜品对应的的口味
        LambdaQueryWrapper<DishFlavor> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DishFlavor::getDishId, dishID);
        dishFlavorService.remove(queryWrapper);

        //将菜品id加到口味上去
        for (DishFlavor flavor : flavors) {
            flavor.setDishId(dishID);
        }
        dishFlavorService.saveBatch(flavors);
    }
}
