package com.cj.hstc.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cj.hstc.entity.Employee;
import org.apache.ibatis.annotations.Mapper;

/**
 * 通过MybatisPlus 已经实现了基础的增删改查
 * 可以查看 BaseMapper 里的方法
 *  @Mapper 使得该类可以被扫描到
 */
@Mapper
public interface EmployeeMapper extends BaseMapper<Employee> {
}
