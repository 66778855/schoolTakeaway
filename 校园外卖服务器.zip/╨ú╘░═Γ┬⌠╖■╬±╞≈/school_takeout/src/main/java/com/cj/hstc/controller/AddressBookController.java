package com.cj.hstc.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.cj.hstc.common.BaseContext;
import com.cj.hstc.common.R;
import com.cj.hstc.entity.AddressBook;
import com.cj.hstc.service.AddressBookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 地址管理
 */
@Slf4j
@RestController
@RequestMapping("/addressBook")
public class AddressBookController {

    @Autowired
    private AddressBookService addressBookService;


    /**
     * 查询用户所有地址
     *
     * @param request
     * @return
     */
    @GetMapping("/list")
    public R<List<AddressBook>> list(HttpServletRequest request) {

        Long userId = (Long) request.getSession().getAttribute("user");

        LambdaQueryWrapper<AddressBook> queryWrapper = new LambdaQueryWrapper<>();
        //添加查询条件 根据分类id查询
        queryWrapper.eq(AddressBook::getUserId, userId);
        queryWrapper.eq(AddressBook::getIsDeleted,0);
        List<AddressBook> addressBooks = addressBookService.list(queryWrapper);

        return R.success(addressBooks);
    }

    /**
     * 修改默认地址
     * @param address
     * @return
     */

    @PutMapping("/default")
    public R<String> setDefault(@RequestBody AddressBook address) {

        Long id = address.getId();
        Long userId = BaseContext.getCurrentId();
        log.info("id" + id + "   userId" + userId);

        LambdaQueryWrapper<AddressBook> queryWrapper = new LambdaQueryWrapper<>();
        //添加查询条件 根据分类id查询
        queryWrapper.eq(AddressBook::getUserId, userId);
        List<AddressBook> addressBooks = addressBookService.list(queryWrapper);
        for (AddressBook addressBook : addressBooks) {
            addressBook.setIsDefault(0);
            if (addressBook.getId().equals(id)) {
                addressBook.setIsDefault(1);
            }
            addressBookService.updateById(addressBook);
        }

        return R.success("修改默认地址成功！");
    }

    /**
     * 新增地址
     * @param addressBook
     * @return
     */

    @PostMapping
    public R<String> save(@RequestBody AddressBook addressBook){
        Long userId = BaseContext.getCurrentId();
        addressBook.setUserId(userId);
        addressBookService.save(addressBook);
        return  R.success("已保存新地址");
    }


    /**
     * 根据地址id查询对应信息
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public R<AddressBook> getById(@PathVariable Long id) {
        AddressBook addressBook = addressBookService.getById(id);
        if (addressBook != null) {
            return R.success(addressBook);
        }
        return R.error("没有查询到对应信息");
    }

    @PutMapping
    public R<String> update(@RequestBody AddressBook addressBook) {
        addressBookService.updateById(addressBook);
        return R.success("修改地址成功");
    }

    @DeleteMapping
    public R<String> delete(Long ids) {
        AddressBook addressBook = addressBookService.getById(ids);
        addressBook.setIsDeleted(1);
        addressBookService.updateById(addressBook);
        return R.success("修改地址成功");
    }

    /**
     * 查询当前用户的默认地址信息
     * @return
     */
    @GetMapping("default")
    public R<AddressBook> defaultAddress() {
        Long userId = BaseContext.getCurrentId();
        LambdaQueryWrapper<AddressBook> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AddressBook::getUserId,userId);
        queryWrapper.eq(AddressBook::getIsDefault,1);
        AddressBook addressBook = addressBookService.getOne(queryWrapper);
        if (addressBook != null) {
            return R.success(addressBook);
        }
        return R.error("没有查询到对应信息");
    }


}
