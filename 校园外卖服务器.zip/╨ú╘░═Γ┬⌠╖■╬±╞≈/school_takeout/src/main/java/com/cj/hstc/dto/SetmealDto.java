package com.cj.hstc.dto;

import com.cj.hstc.entity.Setmeal;
import com.cj.hstc.entity.SetmealDish;
import lombok.Data;
import java.util.List;

@Data
public class SetmealDto extends Setmeal {

    private List<SetmealDish> setmealDishes;

    private String categoryName;
}
