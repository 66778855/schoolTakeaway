package com.cj.hstc.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cj.hstc.common.R;
import com.cj.hstc.dto.DishDto;
import com.cj.hstc.entity.Category;
import com.cj.hstc.entity.Dish;
import com.cj.hstc.entity.SetmealDish;
import com.cj.hstc.service.CategoryService;
import com.cj.hstc.entity.*;
import com.cj.hstc.service.DishFlavorService;
import com.cj.hstc.service.DishService;
import com.cj.hstc.service.SetmealDishService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 菜品管理
 */
@Slf4j
@RestController
@RequestMapping("/dish")
public class DishController {

    @Autowired
    private DishService dishService;

    @Autowired
    private DishFlavorService flavorService;

    @Autowired
    private SetmealDishService setmealDishService;
    @Autowired
    private CategoryService categoryService;

    @PostMapping
    public R<String> save(@RequestBody DishDto dishDto) {
        log.info(dishDto.toString());
        dishService.saveWithFlavor(dishDto);
        return R.success("添加成功");

    }

    /**
     * 因为返回信息中需要包含以及查询出来的 categoryName 菜品分类的名称
     * 所以需要将数据拷贝到pageDtoInfo 中再次处理
     *
     * @param page
     * @param pageSize
     * @param name
     * @return
     */


    @GetMapping("/page")
    public R<Page> page(int page, int pageSize, String name) {

        // 分页构造器
        Page<Dish> pageInfo = new Page<>(page, pageSize);
        Page<DishDto> dishDtoPage = new Page<>();
        //构造条件构造器
        LambdaQueryWrapper<Dish> queryWrapper = new LambdaQueryWrapper<>();
        //添加过滤条件
        queryWrapper.like(name != null, Dish::getName, name);
        queryWrapper.eq(Dish::getIsDeleted, 0);
        //添加排序条件
        queryWrapper.orderByDesc(Dish::getUpdateTime);
        //执行查询
        dishService.page(pageInfo, queryWrapper);
        //对象拷贝，但不拷贝records属性，这个属性里存的就是查出来的数据（好像）
        BeanUtils.copyProperties(pageInfo, dishDtoPage, "records");

        List<Dish> records = pageInfo.getRecords();
        //stream流 jdk8 新特性 好像是
        List<DishDto> list = records.stream().map((item) -> {
            DishDto dishDto = new DishDto();

            BeanUtils.copyProperties(item, dishDto);

            Long categoryId = item.getCategoryId();//分类id

            Category category = categoryService.getById(categoryId);
            if (category != null) {
                String categoryName = category.getName();
                dishDto.setCategoryName(categoryName);
            }

            return dishDto;
        }).collect(Collectors.toList());
        dishDtoPage.setRecords(list);
        return R.success(dishDtoPage);
    }

    /**
     * 修改菜品,中的数据回显
     *
     * @return
     */
    @GetMapping("/{id}")
    public R<DishDto> get(@PathVariable Long id) {

        DishDto dishDto = dishService.getByIdWithFlavor(id);
        return R.success(dishDto);
    }

    /**
     * 修改菜品
     *
     * @return
     */

    @PutMapping
    public R<String> update(@RequestBody DishDto dishDto) {
        log.info(dishDto.toString());
        dishService.updateWithFlavor(dishDto);
        return R.success("修改成功");
    }

    /**
     * 单个删除商品，批量删除商品
     *
     * @param ids
     * @return
     */
    @DeleteMapping
    public R<String> delete(@RequestParam List<Long> ids) {
        int failureNotNull = 0;
        int failureOpen = 0;
        for (Long id : ids) {
            LambdaQueryWrapper<SetmealDish> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(SetmealDish::getDishId, id);
            if (setmealDishService.list(queryWrapper).size() == 0) {
                Dish dish = new Dish();
                dish.setId(id);
                dish.setIsDeleted(1);
                dishService.updateById(dish);
            } else if (dishService.getById(id).getStatus() != 0) {
                failureOpen++;
            } else {
                failureNotNull++;
            }
        }

        if (failureNotNull > 0 || failureOpen>0) {
            return R.error(failureNotNull + "个菜品需要先删除" +
                    "关联套餐，"+failureOpen +"个菜品需要先停售");
        }
        return R.success("删除成功");
    }

    @PostMapping("/status/1")
    public R<String> status_1(@RequestParam List<Long> ids) {

        for (Long id : ids) {
            Dish dish = new Dish();
            dish.setId(id);
            dish.setStatus(1);
            dishService.updateById(dish);
        }
        return R.success("已停售该商品");
    }

    @PostMapping("/status/0")
    public R<String> status_0(@RequestParam List<Long> ids) {

        for (Long id : ids) {
            Dish dish = new Dish();
            dish.setId(id);
            dish.setStatus(0);
            dishService.updateById(dish);
        }
        return R.success("已停售该商品");
    }


    /**
     * 添加套餐中，根据分类查询菜品
     *
     * @param categoryId
     * @return
     */
    @GetMapping("/list")
    public R<List<DishDto>> list(Long categoryId) {
        List<DishDto> dishDtoList = dishService.getByIdWithFlavorList(categoryId);
        return R.success(dishDtoList);
    }

}