package com.cj.hstc.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cj.hstc.common.R;
import com.cj.hstc.dto.SetmealDto;
import com.cj.hstc.entity.Category;
import com.cj.hstc.entity.Setmeal;
import com.cj.hstc.service.CategoryService;
import com.cj.hstc.entity.*;
import com.cj.hstc.service.SetmealService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * 套餐管理
 */

@Slf4j
@RestController
@RequestMapping("/setmeal")
public class SetmealController {

    @Autowired
    private SetmealService setmealService;

    @Autowired
    private CategoryService categoryService;


    /**
     * 页面展示数据查询
     *
     * @param page
     * @param pageSize
     * @param name
     * @return
     */
    @GetMapping("/page")
    public R<Page> page(int page, int pageSize, String name) {

        // 分页构造器
        Page<Setmeal> pageInfo = new Page<>(page, pageSize);
        Page<SetmealDto> setmealDtoPage = new Page<>();
        List<SetmealDto> setmealDtos = new ArrayList<>();
        //构造条件构造器
        LambdaQueryWrapper<Setmeal> queryWrapper = new LambdaQueryWrapper<>();
        //添加过滤条件
        queryWrapper.like(StringUtils.isNotEmpty(name), Setmeal::getName, name);
        queryWrapper.eq(Setmeal::getIsDeleted, 0);
        //执行查询
        setmealService.page(pageInfo, queryWrapper);

        //对象拷贝，但不拷贝records属性，这个属性里存的就是查出来的数据（好像）
        BeanUtils.copyProperties(pageInfo, setmealDtoPage, "records");

        List<Setmeal> records = pageInfo.getRecords();
        for (Setmeal record : records) {
            //获取到套餐分类的ID
            Long categoryId = record.getCategoryId();
            //将Setmeal类型的record中的数据复制到setmealDto中
            SetmealDto setmealDto = new SetmealDto();
            BeanUtils.copyProperties(record, setmealDto);
            //查询并将名字设置到setmealDto中
            Category category = categoryService.getById(categoryId);
            String categoryName = category.getName();
            setmealDto.setCategoryName(categoryName);
            setmealDtos.add(setmealDto);
        }
        setmealDtoPage.setRecords(setmealDtos);
        return R.success(setmealDtoPage);
    }

    @PostMapping
    public R<String> save(@RequestBody SetmealDto setmealDto) {
        setmealService.saveWithSetmealDish(setmealDto);
        return R.success("添加成功");
    }

    /**
     * 删除套餐 (批量，单个)
     *
     * @param ids
     * @return
     */
    @DeleteMapping
    public R<String> delete(@RequestParam List<Long> ids) {

        int failure = setmealService.deleteWithDish(ids);
        if (failure > 0) {
            return R.error(failure + "行删除失败");
        } else {
            return R.success("删除成功");
        }
    }



    /**
     * 启售套餐
     *
     * @param ids
     * @return
     */
     @PostMapping("/status/1")
    public R<String> status_1(@RequestParam List<Long> ids) {
        for (Long id : ids) {
            Setmeal setmeal = new Setmeal();
            setmeal.setId(id);
            setmeal.setStatus(1);
            setmealService.updateById(setmeal);
        }
        return R.success("已启售该套餐");
    }

    /**
     * 停售套餐
     *
     * @param ids
     * @return
     */
    @PostMapping("/status/0")
    public R<String> status_0(@RequestParam List<Long> ids) {
        for (Long id : ids) {
            Setmeal setmeal = new Setmeal();
            setmeal.setId(id);
            setmeal.setStatus(0);
            setmealService.updateById(setmeal);
        }
        return R.success("已停售该套餐");
    }


    /**
     * 修改套餐,中的数据回显
     *
     * @return
     */
    @GetMapping("/{id}")
    public R<SetmealDto> get(@PathVariable Long id) {

        SetmealDto setmealDto = setmealService.getWithSetmealDish(id);
        return R.success(setmealDto);
    }


    /**
     * 查询套餐中的菜品
     * @param categoryId
     * @return
     */
    @GetMapping("/list")
    public R<List<Setmeal>> list(Long categoryId){
        //构造条件构造器
        LambdaQueryWrapper<Setmeal> queryWrapper = new LambdaQueryWrapper<>();

        queryWrapper.eq(Setmeal::getCategoryId,categoryId);
        //只查询状态为1 的启售商品
        queryWrapper.eq(Setmeal::getStatus,1);
        //添加排序条件
        queryWrapper.orderByDesc(Setmeal ::getUpdateTime);
        //执行查询
        List<Setmeal> list =setmealService.list(queryWrapper);
        return R.success(list);
    }


}
