package com.cj.hstc.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cj.hstc.entity.User;
import com.cj.hstc.mapper.UserMapper;
import com.cj.hstc.service.UserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
}
