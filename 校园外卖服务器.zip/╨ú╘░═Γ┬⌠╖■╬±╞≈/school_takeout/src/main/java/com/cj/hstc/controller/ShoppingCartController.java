package com.cj.hstc.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.cj.hstc.common.BaseContext;
import com.cj.hstc.common.R;
import com.cj.hstc.entity.ShoppingCart;
import com.cj.hstc.service.ShoppingCartService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/shoppingCart")
public class ShoppingCartController {

    @Autowired
    private ShoppingCartService shoppingCartService;

    /**
     * 用户购物车
     *
     * @return
     */
    @GetMapping("/list")
    public R<List<ShoppingCart>> list() {
        Long userId = BaseContext.getCurrentId();
        LambdaQueryWrapper<ShoppingCart> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ShoppingCart::getUserId, userId);
        queryWrapper.orderByAsc(ShoppingCart::getCreateTime);
        List<ShoppingCart> list = shoppingCartService.list();
        return R.success(list);
    }

    /**
     * 向购物车中添加商品
     *
     * @param shoppingCart
     * @return
     */

    @PostMapping("/add")
    public R<String> add(@RequestBody ShoppingCart shoppingCart) {
        Long userId = BaseContext.getCurrentId();
        LambdaQueryWrapper<ShoppingCart> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ShoppingCart::getUserId, userId);
        List<ShoppingCart> shoppingCartList = shoppingCartService.list(queryWrapper);

        for (ShoppingCart cart : shoppingCartList) {

            //菜品 和 口味都一样 加数量，否则插入新的数据
            if ((shoppingCart.getDishId() != null && cart.getDishId() != null && cart.getDishId()
                    .equals(shoppingCart.getDishId())) &&
                    ((cart.getDishFlavor() == null && shoppingCart.getDishFlavor() == null)
                            || (cart.getDishFlavor() != null
                            && shoppingCart.getDishFlavor() != null && cart.getDishFlavor().equals
                            (shoppingCart.getDishFlavor())))) {
                cart.setNumber(cart.getNumber() + 1);
                shoppingCartService.updateById(cart);
                return R.success("添加到购物车成功");
            } else if ((shoppingCart.getSetmealId() != null && cart.getSetmealId() != null) &&
                    cart.getSetmealId().equals(shoppingCart.getSetmealId())) {
                cart.setNumber(cart.getNumber() + 1);
                shoppingCartService.updateById(cart);
                return R.success("添加到购物车成功");
            }
        }
        shoppingCart.setCreateTime(LocalDateTime.now());
        shoppingCart.setUserId(userId);
        shoppingCartService.save(shoppingCart);
        return R.success("添加到购物车成功");
    }


    @PostMapping("/sub")
    public R<String> sub(@RequestBody ShoppingCart shoppingCart) {
        Long userId = BaseContext.getCurrentId();
        LambdaQueryWrapper<ShoppingCart> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ShoppingCart::getUserId, userId);
        if (shoppingCart.getDishId() != null) {
            queryWrapper.eq(ShoppingCart::getDishId, shoppingCart.getDishId());
        } else {
            queryWrapper.eq(ShoppingCart::getSetmealId, shoppingCart.getSetmealId());
        }
        ShoppingCart one = shoppingCartService.getOne(queryWrapper);
        if (one.getNumber() > 1) {
            one.setNumber(one.getNumber() - 1);
            shoppingCartService.updateById(one);
            return R.success(one.getName() +"减一");
        }
        shoppingCartService.remove(queryWrapper);
        return R.success("移除购物车成功");
    }


    /**
     * 清空购物车
     *
     * @return
     */
    @DeleteMapping("/clean")
    public R<String> delete() {
        shoppingCartService.delete();
        return R.success("清空购物车成功");
    }

}
