package com.cj.hstc.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cj.hstc.entity.Orders;


public interface OrdersService extends IService<Orders>{

    public void submit(Orders orders);
    public void again(Long id);
}
