package com.cj.hstc.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cj.hstc.common.CustomException;
import com.cj.hstc.entity.Category;
import com.cj.hstc.entity.Dish;
import com.cj.hstc.entity.Setmeal;
import com.cj.hstc.mapper.CategoryMapper;
import com.cj.hstc.service.CategoryService;
import com.cj.hstc.service.DishService;
import com.cj.hstc.service.SetmealService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CategoryServiceImpl extends ServiceImpl<CategoryMapper, Category> implements CategoryService {

    @Autowired
    private DishService dishService;
    @Autowired
    private SetmealService setmealService;

    @Override
    public void remove(Long id) {
        LambdaQueryWrapper<Dish> dishLambdaQueryWrapper = new LambdaQueryWrapper<>();
        //添加查询条件 根据分类id查询
        dishLambdaQueryWrapper.eq(Dish::getCategoryId, id);
        int count1 = dishService.count(dishLambdaQueryWrapper);
        //查询当前分类是否关联了菜品，如果已经关联 抛出一个业务异常
        if (count1 > 0) {
            //查询结果大于零 说明关联了菜品 抛出一个业务异常
            throw new CustomException("请先删除该分类关联的菜品！");
        }

        //查询当前分类是否关联了套餐，如果已经关联，抛出一个业务异常
        LambdaQueryWrapper<Setmeal> setmealLambdaQueryWrapper = new LambdaQueryWrapper<>();
        //添加查询条件，根据分类id进行查询
        setmealLambdaQueryWrapper.eq(Setmeal::getCategoryId, id);
        int count2 = setmealService.count(setmealLambdaQueryWrapper);
        if (count2 > 0) {
            //查询结果大于零 说明关联了套餐 抛出一个业务异常
            throw new CustomException("请先删除该分类关联的套餐！");
        }
        //没出现上述情况，则删除该分类（需要改进为通过字段 0 1 标记是否删除）
        super.removeById(id);
    }
}
