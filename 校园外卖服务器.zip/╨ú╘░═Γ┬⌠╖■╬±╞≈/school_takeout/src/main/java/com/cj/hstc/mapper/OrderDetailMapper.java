package com.cj.hstc.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cj.hstc.entity.OrderDetail;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OrderDetailMapper extends BaseMapper<OrderDetail> {
}
