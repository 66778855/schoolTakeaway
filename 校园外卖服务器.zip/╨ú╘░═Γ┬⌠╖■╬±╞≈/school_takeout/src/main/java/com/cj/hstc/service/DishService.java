package com.cj.hstc.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cj.hstc.dto.DishDto;
import com.cj.hstc.entity.Dish;

import java.util.List;

public interface DishService extends IService<Dish> {

    //新增菜品，操作菜品 口味两张表
    public void  saveWithFlavor(DishDto dishDto);

    //根据菜品id查询对应信息及口味
    public DishDto getByIdWithFlavor(Long id);

    //新增菜品，操作菜品 口味两张表
    public void  updateWithFlavor(DishDto dishDt);

    public List<DishDto> getByIdWithFlavorList(Long categoryId);

}
