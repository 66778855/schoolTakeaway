package com.cj.hstc.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cj.hstc.entity.Employee;
import com.cj.hstc.mapper.EmployeeMapper;
import com.cj.hstc.service.EmployeeService;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl extends ServiceImpl<EmployeeMapper, Employee> implements EmployeeService {
}
