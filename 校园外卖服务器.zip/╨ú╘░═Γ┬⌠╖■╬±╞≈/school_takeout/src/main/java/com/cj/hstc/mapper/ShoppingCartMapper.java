package com.cj.hstc.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cj.hstc.entity.ShoppingCart;
import org.apache.ibatis.annotations.Mapper;

/**
 * 购物车
 */
@Mapper
public interface ShoppingCartMapper extends BaseMapper<ShoppingCart> {
}
