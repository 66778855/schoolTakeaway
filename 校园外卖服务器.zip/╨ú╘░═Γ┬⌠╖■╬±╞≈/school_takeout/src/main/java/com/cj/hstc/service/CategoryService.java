package com.cj.hstc.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cj.hstc.entity.Category;

public interface CategoryService extends IService<Category> {
    void remove(Long id);
}
