package com.cj.hstc.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cj.hstc.entity.DishFlavor;

public interface DishFlavorService extends IService<DishFlavor> {
}
