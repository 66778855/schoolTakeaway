package com.cj.hstc.common;

/**
 * 基于ThreadLocal封装的工具类，用于保存和获取当前登陆用户的id
 * 当然在一个请求内都是一个线程，也可以用来传输其他值
 */
public class BaseContext {
    private static ThreadLocal<Long> threadLocal = new ThreadLocal<>();

    /**
     * 设置值
     * @param id
     */
    public static void setCurrentId(Long id){
        threadLocal.set(id);
    }

    /**
     * 获取值
     * @return
     */
    public static Long getCurrentId(){
        return threadLocal.get();
    }
}