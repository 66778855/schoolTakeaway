package com.cj.hstc.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cj.hstc.entity.SetmealDish;
import com.cj.hstc.mapper.SetmealDishMapper;
import com.cj.hstc.service.SetmealDishService;
import com.cj.hstc.service.SetmealService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SetmealDishServiceImpl extends ServiceImpl<SetmealDishMapper, SetmealDish> implements SetmealDishService {


    @Autowired
    private SetmealService setmealService;

}
