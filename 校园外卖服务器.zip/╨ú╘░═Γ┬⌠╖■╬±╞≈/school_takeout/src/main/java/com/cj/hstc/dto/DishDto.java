package com.cj.hstc.dto;

import com.cj.hstc.entity.Dish;
import com.cj.hstc.entity.DishFlavor;
import lombok.Data;
import java.util.ArrayList;
import java.util.List;

/**
 * 继承了实体类Dish ，补充了两个属性，专门用于接收信息，更加规范
 */
@Data
public class DishDto extends Dish {

    private List<DishFlavor> flavors = new ArrayList<>();

    private String categoryName;

    private Integer copies;
}
