package com.cj.hstc.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 员工实体类 与 员工表映射
 *
 * @Data 帮我们写好Get Set ToString等一些方法
 */
@Data
public class Employee {
    private Long id;
    private String name;
    private String username;
    private String password;
    private String phone;
    private String sex;
    private String idNumber;//身份证号码（yml中开启了驼峰命名法）
    private Integer status;
    @TableField(fill = FieldFill.INSERT)    //插入时填充字段 (公共字段自动填充)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)     //插入和更新时填充字段
    private LocalDateTime updateTime;
    @TableField(fill = FieldFill.INSERT)
    private Long createUser;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Long updateUser;
}
