package com.cj.hstc.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cj.hstc.entity.DishFlavor;
import com.cj.hstc.mapper.DishFlavorMapper;
import com.cj.hstc.service.DishFlavorService;
import org.springframework.stereotype.Service;

@Service
public class DishFlavorImpl extends ServiceImpl<DishFlavorMapper, DishFlavor> implements DishFlavorService {


}
