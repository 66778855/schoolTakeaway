package com.cj.hstc.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cj.hstc.dto.SetmealDto;
import com.cj.hstc.entity.Setmeal;

import java.util.List;

public interface SetmealService extends IService<Setmeal> {
    public void saveWithSetmealDish(SetmealDto setmealDto) ;
    public SetmealDto getWithSetmealDish(Long id) ;

    public  int  deleteWithDish(List<Long> ids);
}
