package com.cj.hstc.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cj.hstc.entity.Orders;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OrdersMapper extends BaseMapper<Orders> {
}
