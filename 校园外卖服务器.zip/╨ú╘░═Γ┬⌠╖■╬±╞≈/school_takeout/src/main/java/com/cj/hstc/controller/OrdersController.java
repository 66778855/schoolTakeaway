package com.cj.hstc.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cj.hstc.common.BaseContext;
import com.cj.hstc.common.R;
import com.cj.hstc.entity.Orders;
import com.cj.hstc.service.OrdersService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/order")
public class OrdersController {

    @Autowired
    private OrdersService ordersService;


    @PostMapping("/submit")
    public R<String> submit(@RequestBody Orders orders) {
        ordersService.submit(orders);
        return R.success("下单成功");
    }

    /**
     * 个人中心，信息查询
     *
     * @param page
     * @param pageSize
     * @return
     */

    @GetMapping("/userPage")
    public R<Page> userPage(int page, int pageSize) {
        Long userId = BaseContext.getCurrentId();
        // 分页构造器
        Page pageInfo = new Page(page, pageSize);
        //构造条件构造器
        LambdaQueryWrapper<Orders> queryWrapper = new LambdaQueryWrapper<>();
        //添加过滤条件
        queryWrapper.eq(Orders::getUserId, userId);
        //添加排序条件
        //执行查询
        ordersService.page(pageInfo, queryWrapper);
        return R.success(pageInfo);
    }

    //  , DateTimeFormatter beginTime, DateTimeFormatter endTime
    @GetMapping("/page")
    public R<Page> page(int page, int pageSize, Long number) {
        // 分页构造器
        Page pageInfo = new Page(page, pageSize);
        //构造条件构造器
        LambdaQueryWrapper<Orders> queryWrapper = new LambdaQueryWrapper<>();
        //添加过滤条件
        queryWrapper.like(number != null, Orders::getId, number);
//        queryWrapper.in(beginTime!=null&endTime!=null,beginTime,endTime);
        ordersService.page(pageInfo, queryWrapper);
        return R.success(pageInfo);
    }

    @PutMapping
    public R<String> update(@RequestBody Orders orders) {
        ordersService.updateById(orders);
        return R.success("更新订单状态成功");
    }

    @PostMapping("/again")
    public R<String> again(@RequestBody Orders orders) {
        ordersService.again(orders.getId());
        return R.success("更新订单状态成功");
    }

}
