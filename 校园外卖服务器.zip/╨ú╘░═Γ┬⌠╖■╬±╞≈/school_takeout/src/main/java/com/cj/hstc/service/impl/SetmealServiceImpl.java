package com.cj.hstc.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cj.hstc.dto.SetmealDto;
import com.cj.hstc.entity.Setmeal;
import com.cj.hstc.entity.SetmealDish;
import com.cj.hstc.mapper.SetmealMapper;
import com.cj.hstc.service.SetmealDishService;
import com.cj.hstc.service.SetmealService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SetmealServiceImpl extends ServiceImpl<SetmealMapper, Setmeal> implements SetmealService {


    @Autowired
    private SetmealService setmealService;

    @Autowired
    private SetmealDishService setmealDishService;

    @Override
    @Transactional
    public void saveWithSetmealDish(SetmealDto setmealDto) {
        setmealService.save(setmealDto);
        List<SetmealDish> setmealDishes = setmealDto.getSetmealDishes();
        for (SetmealDish dish : setmealDishes) {
            dish.setSetmealId(setmealDto.getId());
        }
        setmealDishService.saveBatch(setmealDishes);

    }

    @Override
    public SetmealDto getWithSetmealDish(Long id) {
        SetmealDto setmealDto = new SetmealDto();
        Setmeal setmeal = setmealService.getById(id);
        BeanUtils.copyProperties(setmeal,setmealDto);
        return setmealDto;
    }

    /**
     * 删除套餐，并删除相关联的菜品关系
     * 返回删除成功的行数
     * @param ids
     * @return
     */

    @Override
    @Transactional
    public int deleteWithDish(List<Long> ids) {
        //记录删除失败的行数
        int failure = 0;
        for (Long id : ids) {
            //构造条件构造器
            LambdaQueryWrapper<Setmeal> queryWrapper = new LambdaQueryWrapper<>();
            //添加过滤条件
            queryWrapper.eq(Setmeal::getId, id);
            Setmeal setmeal = setmealService.getOne(queryWrapper);
            if (setmeal.getStatus() != 0) {
                failure++;
            }else {
                //删除套餐
                setmeal.setIsDeleted(1);
                setmealService.updateById(setmeal);
                //删除对应的菜品关系
                LambdaQueryWrapper<SetmealDish> setmealDishWrapper = new LambdaQueryWrapper<>();
                //添加过滤条件
                setmealDishWrapper.eq(SetmealDish::getSetmealId, id);
                List<SetmealDish> setmealDishs = setmealDishService.list(setmealDishWrapper);
                for (SetmealDish setmealDish : setmealDishs) {
                    setmealDish.setIsDeleted(1);
                    setmealDishService.updateById(setmealDish);
                }
            }
        }
        return failure;
    }
}
