package com.cj.hstc.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cj.hstc.common.BaseContext;
import com.cj.hstc.entity.*;
import com.cj.hstc.service.AddressBookService;
import com.cj.hstc.service.OrdersService;
import com.cj.hstc.entity.*;
import com.cj.hstc.mapper.OrdersMapper;
import com.cj.hstc.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class OrdersServiceImpl extends ServiceImpl<OrdersMapper, Orders> implements OrdersService {

    @Autowired
    private AddressBookService addressBookService;
    @Autowired
    private DishService dishService;
    @Autowired
    private UserService userService;
    @Autowired
    private ShoppingCartService shoppingCartService;
    @Autowired
    private OrderDetailService orderDetailService;

    @Override
    @Transactional
    public void submit(Orders orders) {
        Long userId = BaseContext.getCurrentId();

        //用工具类生成id 设置为订单号
        Long orderId = IdWorker.getId();//订单号
        orders.setNumber(String.valueOf(orderId));
        orders.setId(orderId);


        orders.setUserId(userId);
        //设置为待付款
        orders.setStatus(1);

        //设置为微信支付 和 支付时间 下单时间
        orders.setOrderTime(LocalDateTime.now());
        orders.setPayMethod(1);
        orders.setCheckoutTime(LocalDateTime.now());
        //设置为待派送
        orders.setStatus(2);

        Long addressBookId = orders.getAddressBookId();
        AddressBook addressBook = addressBookService.getById(addressBookId);
        orders.setAddress(addressBook.getDetail());
        orders.setConsignee(addressBook.getConsignee());
        orders.setPhone(addressBook.getPhone());
        User user = userService.getById(userId);
        orders.setUserName(user.getName());
        //查询购物车内容
        LambdaQueryWrapper<ShoppingCart> shoppingCartQW = new LambdaQueryWrapper<>();
        shoppingCartQW.eq(ShoppingCart::getUserId, userId);
        List<ShoppingCart> shoppingCartList = shoppingCartService.list(shoppingCartQW);

        //原子类整数 保证线程安全
        AtomicInteger amount = new AtomicInteger(0);
        //计算订单总额并将购物车中的数据放入订单详情
        for (ShoppingCart shoppingCart : shoppingCartList) {
            amount.addAndGet(shoppingCart.getAmount().multiply(new BigDecimal(shoppingCart.getNumber())).intValue());
            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setName(shoppingCart.getName());
            orderDetail.setImage(shoppingCart.getImage());
            orderDetail.setOrderId(orderId);
            if (shoppingCart.getDishId() != null) {
                orderDetail.setDishId(shoppingCart.getDishId());
            } else {
                orderDetail.setSetmealId(shoppingCart.getSetmealId());
            }
            if (shoppingCart.getDishFlavor() != null) {
                orderDetail.setDishFlavor(shoppingCart.getDishFlavor());
            }
            orderDetail.setNumber(shoppingCart.getNumber());
            orderDetail.setAmount(new BigDecimal((shoppingCart.getAmount().intValue() * shoppingCart.getNumber())));
            orderDetailService.save(orderDetail);

        }
        orders.setAmount(new BigDecimal(amount.get()));
        this.save(orders);
        //清空购物车
        shoppingCartService.delete();
    }

    @Override
    @Transactional
    public void again(Long id) {
//        Orders newOrder = new Orders();
//        Orders oldOrder = this.getById(id);
//        BeanUtils.copyProperties(oldOrder,newOrder);
//        //用工具类生成id 设置为订单号
//        Long orderId = IdWorker.getId();//订单号
//        newOrder.setNumber(String.valueOf(orderId));
//        newOrder.setId(orderId);
//        this.save(newOrder);
//
//        LambdaQueryWrapper<OrderDetail> orderDetailQueryWrapper = new LambdaQueryWrapper<>();
//        orderDetailQueryWrapper.eq(OrderDetail::getId,id);
//        List<OrderDetail> orderDetailList = orderDetailService.list(orderDetailQueryWrapper);
//        for (OrderDetail orderDetail : orderDetailList) {
//            Long detailId = IdWorker.getId();//订单号
//            orderDetail.setId(detailId);
//            orderDetail.setOrderId(orderId);
//        }
//        orderDetailService.saveBatch(orderDetailList);
        //清空购物车
        shoppingCartService.delete();
        //将订单关联的数据传递到购物车中
        LambdaQueryWrapper<OrderDetail> orderDetailQueryWrapper = new LambdaQueryWrapper<>();
        orderDetailQueryWrapper.eq(OrderDetail::getOrderId, id);
        List<OrderDetail> orderDetailList = orderDetailService.list(orderDetailQueryWrapper);
        for (OrderDetail orderDetail : orderDetailList) {
            ShoppingCart shoppingCart = new ShoppingCart();
            //也可以通过order中的id获取order中的userId 因为再来一单一定是
            // 在同一个用户登陆的环境下发出的请求
            Long userId = BaseContext.getCurrentId();
            shoppingCart.setUserId(userId);
            shoppingCart.setAmount(new BigDecimal(orderDetail.getAmount().intValue()/orderDetail.getNumber()));
            shoppingCart.setCreateTime(LocalDateTime.now());
            if (orderDetail.getDishFlavor() != null) {
                shoppingCart.setDishFlavor(orderDetail.getDishFlavor());
            }
            if (orderDetail.getDishId() != null){
                shoppingCart.setDishId(orderDetail.getDishId());
            }else {
                shoppingCart.setSetmealId(orderDetail.getSetmealId());
            }
            shoppingCart.setImage(orderDetail.getImage());
            shoppingCart.setName(orderDetail.getName());
            shoppingCart.setNumber(orderDetail.getNumber());
            shoppingCartService.save(shoppingCart);
        }

    }
}
