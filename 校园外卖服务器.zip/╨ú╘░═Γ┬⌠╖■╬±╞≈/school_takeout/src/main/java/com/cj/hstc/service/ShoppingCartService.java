package com.cj.hstc.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cj.hstc.entity.ShoppingCart;

public interface ShoppingCartService extends IService<ShoppingCart> {
    public void delete();
}
